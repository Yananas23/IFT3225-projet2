// - gameRoutes.js : Gère les routes du jeu (def et word) pour récupérer des mots aléatoires, jouer, et mettre à jour les scores.
const express = require("express");
const sequelize = require("../config/database"); // Les requêtes paramétérées de sequelize.query devrait en général empêcher l'injection de sql
const Joueur = require("../models/joueur");
const Word = require("../models/word");
const allowedLangs = ["en", "fr"]; // Langues supportées
const router = express.Router();

// ROUTES

router.get("/word/:lg?/:time?/:hint?", async (req, res) => {
    try {
        const { lg = "en", time = 60 } = req.params;  // Langue et temps par défaut
        const hintIntervalTime = req.params.hint || 10;  // Par défaut, 10 secondes

        

        if (!allowedLangs.includes(lg)) return res.status(400).send("Langue non supportée.");

        if (containsScriptTags(time)) {
            res.status(400).send('Infâme tentative d\'attaque XSS détectée!');
        }

        if (containsScriptTags(hintIntervalTime)) {
            res.status(400).send('Ignoble tentative d\'attaque XSS détectée!');
        }

        // Récupérer un mot aléatoire de la langue spécifiée
        const wordData = await getRandomWord(lg);
        if (!wordData) {
            return res.status(404).send("Aucun mot trouvé.");
        }

        const { word, wordId, definition } = wordData;

        // Initialiser le score du joueur pour la partie
        const initialScore = 10 * word.length;
        let score = initialScore;

        // Score global du joueur
        const globalScore = req.session.joueur?.score || -1;

        // Mots suggérés
        const suggestions = await Word.FindSuggestions(word, lg);

        // Si le joueur est connecté, on récupère son pseudo
        const pseudo = req.session.joueur?.pseudo || "";

        // Afficher la page de jeu avec les informations nécessaires
        res.render("game", {
            layout: "layout",
            title: "Jeu des mots",
            word,
            wordId,
            definition,
            timeLimit: time,
            score,
            pseudo,
            globalScore,
            hintIntervalTime,
            suggestions,
        });

    } catch (err) {
        console.error(err);
        res.status(500).send("Erreur lors de la création du jeu.");
    }
});

router.post("/word/score", async (req, res) => {
    try {
        const pseudo = req.session.joueur?.pseudo;
        const winScore = parseInt(req.body.score, 10);

        if (!pseudo || isNaN(winScore)) {
            return res.status(400).json({ error: 'Score ou ID utilisateur manquant.' });
        }

        // Récupérer le joueur
        const joueur = await Joueur.findOne({ where: { pseudo } });
        if (!joueur) {
            return res.status(404).json({ message: "Joueur introuvable!" });
        }

        const nouveauScore = (joueur.score || 0) + winScore;

        // Joueur.update
        await Joueur.update(
            { score: nouveauScore },
            { where: { pseudo } }
        );

        // Mettre à jour la session
        req.session.joueur.score = nouveauScore;

        res.json({ message: "Score mis à jour", nouveauScore });
    } catch (err) {
        console.error("Erreur dans /word/score :", err);
        res.status(500).json({ message: "Erreur serveur" });
    }
});


router.get("/def/:lg?/:time?", async (req, res) => {
    try {      
        const lang = req.params.lg || "en";
        const time = parseInt(req.params.time, 10) || 60;

        if (!allowedLangs.includes(lang)) return res.status(400).send("Langue non supportée.");
        
        const wordData = await getRandomWord(lang);
        if (!wordData) {
            return res.status(404).send("Aucun mot trouvé.");
        }

        const pseudo = req.session.joueur?.pseudo || null;
        let score = -1;

        if (pseudo) {
            // Par une requête SQL manuelle :
            const joueurResponse = await sequelize.query(
                `SELECT * FROM joueur WHERE pseudo = ?`,
                [pseudo]
              );
            
            const joueur = joueurResponse[0]; // Le premier élément du tableau retourné (si un joueur existe)
            score = joueur?.score ?? -1;
        }

        res.render("def", {
            layout: "layout",
            title: "Jeu des définitions",
            word: wordData.word,
            wordId: wordData.wordId,
            language: lang,
            time,
            isConnected: !!pseudo,
            pseudo,
            globalScore: score,
        });

    } catch (err) {
        console.error("Erreur dans /def/ :", err);
        res.status(500).send("Erreur lors de la génération de la partie.");
    }
});

router.post("/def/:wordId", async (req, res) => {
    try {
        const wordId = parseInt(req.params.wordId, 10);
        if (isNaN(wordId) || wordId <= 0) {
            return res.status(400).json({ error: 'Identifiant de mot invalide.' });
        }
        const { definitions } = req.body;

        if (containsScriptTags(definitions)) {
            res.status(400).send('Méprisable tentative d\'attaque XSS détectée!');
        }

        // console.log(`Définitions reçues pour le mot ${wordId} :`, definitions);

        const pseudo = req.session.joueur?.pseudo || "";
        const source = req.session.joueur?.pseudo || "Joueur anonyme";

        // Requête SQL manuelle pour récupérer le mot avec son ID
        const wordData = await sequelize.query(
            `SELECT * FROM word WHERE id = ?`, 
            [wordId]
        );

        if (!wordData || wordData.length === 0) {
            return res.status(404).send("Mot non trouvé.");
        }        

        // Requête SQL manuelle pour récupérer les définitions existantes
        const existingDefsResponse = await sequelize.query(
            `SELECT * FROM definition d 
             JOIN word_definition wd ON d.id = wd.\`d-id\` 
             WHERE wd.\`w-id\` = ?`, [wordId]
        );

        const existingDefs = existingDefsResponse.data;

        // Créer un ensemble des définitions déjà existantes (pour éviter les doublons)
        const existingTexts = new Set(existingDefs.map(def => def.definition.toLowerCase()));

        let validDefs = 0;
        for (let def of definitions) {
            if (!def || typeof def !== 'string' || def.trim().length === 0) {
                // Si la définition est invalide (null, undefined ou vide), on la saute
                continue;
            }

            const text = def.trim();
            if (text.length < 5 || text.length > 200) continue; // Sauter si longuer incorrecte
            if (existingTexts.has(text.toLowerCase())) continue; // Sauter si la définition existe déjà

            // Si la définition est valide, on l'ajoute à la base de données
            const newDefResponse = await sequelize.query(
                `INSERT INTO definition (definition, source) VALUES (?, ?)`,
                [text, source]
            );

            const newDefId = newDefResponse.insertId;
            // console.log("Def response! ", newDefId)

            // Création de l'association entre le mot et la définition
            await sequelize.query(
                `INSERT INTO word_definition (\`w-id\`, \`d-id\`) VALUES (?, ?)`,
                [wordId, newDefId],
            );

            validDefs++;
        }

        let updatedScore = -1;
        if (req.session.joueur && validDefs > 0) {
            // Par une requête SQL manuelle :
            const joueurResponse = await sequelize.query(
                `SELECT * FROM joueur WHERE pseudo = ?`,
                [pseudo]
            );
            
            // console.log("Joueur Response : ", joueurResponse);
            const joueur = joueurResponse[0];
            updatedScore = joueur.score + validDefs * 5;
            await Joueur.update({ score: updatedScore }, { where: { pseudo } });
            req.session.joueur.score = updatedScore;
        }

        res.json({
            success: true,
            pseudo,
            gainedPoints: validDefs * 5, // Points pour la partie
            updatedScore, // Score global du joueur
            isConnected: !!req.session.joueur
        });

    } catch (err) {
        console.error(err);
        res.status(500).send("Erreur lors de la soumission.");
    }
});

// FONCTIONS

function containsScriptTags(input) {
    const regex = /<script.*?>.*?<\/script>/gi;
    return regex.test(input);
}

async function getRandomWord(lang = "en") {
    try {
        // Récupérer tous les mots de la langue
        const words = await Word.findAll({ where: { lang } });
        if (!words || words.length === 0) return null;

        // On prend l’id des mots trouvés
        const wordIds = words.data.map(w => w.id);

        // Aller chercher les définitions pour ces mots
        const definitionsRaw = await sequelize.query(
            `SELECT w.id as wordId, w.word, d.id as definitionId, d.definition
             FROM word w
             JOIN word_definition wd ON w.id = wd.\`w-id\`
             JOIN definition d ON d.id = wd.\`d-id\`
             WHERE w.lang = ?`,
            [lang]
        );

        const defs = definitionsRaw.data;

        if (defs.length === 0) return null;

        // Choisir un mot/définition aléatoire
        const random = defs[Math.floor(Math.random() * defs.length)];

        return {
            word: random.word,
            wordId: random.wordId,
            definition: random.definition,
            definitionId: random.definitionId
        };

    } catch (err) {
        console.error("Erreur dans getRandomWord :", err);
        return null;
    }
}

module.exports = router;